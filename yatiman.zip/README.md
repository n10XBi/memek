### This script is not updated, contact us to get the latest updated script

## 📞 CREATOR SCRIPT: [Jeremy (Neribot Owner)](https://wa.me/6282213162100)
### 📞 Recoder: [Jarsepay](https://wa.me/6282148864989)
![cover](https://telegra.ph/file/476dabd35c800091e0357.jpg)

<h1 align="center">Jarspy - Bot</h1>

# Introduction
Jarspy is a WhatsApp Bot with many multifunctional features, using [Games-Wabot Base](https://github.com/BochilGaming/games-wabot) from [BochilGaming](https://github.com/BochilGaming) with Neri Bot combination by [Jeremy](https://wa.me/6282213162100)

### The features we provide
- AI: OpenAI, AI Character, Bing, Bing Image, To Anime, To Zombie, etc.
- Anime: Animeinfo, Mangainfo, Random Anime Pfp, Anime Couple Pfp, etc.
- Downloader: Instagram, TikTok, Facebook, Danbooru, Gitclones, Mediafire, Pixiv, etc.
- Tools: Lookup, Photo Enhancer, Short Url, etc.
- Sticker: Sticker Maker, Sticker to Video, Gif To Sticker, Watermark a Sticker, etc.
- Group: Ban Chat, Kick Member, Hidetags, Welcome & Bye, Demote, Promote, Invite, etc.
- Anonymous: Start, Leave, Next
- Jadi Bot: Become a clone bot, and seeing list of the cloned bot
- Owner: Broadcasts, Add & Delete Premium Users, Get Plugin, Cheat, Get Sessions, Randompicks for giveaway, etc.
- Youtube: Play Audio, Youtube Video & Audio, Youtube Transcript, etc.
- Internet: Google Image Search, Weather, Earthquake Information, Random Facts, Random Jokes, Yandex, etc.
- Game: Bomb, Chess, Ulartangga, Hangman, Guess, Police, Werewolf, etc.
- Roleplaying Games: Adventure, Daily, Mining, Hunting, Trading, Transferring, Opening Crates, Gambling, Improve your Ability, Apply for Job, Confess to your favorite Waifu & Husbu, Date with your Waifu & Husbu, Follow or Confess with real person, Kill a person, Jail someone with Police jobs, Heal a low hp players with Doctor jobs, Go eat or starve and died, Get Quest, Move Location, Select your own skills, and many more!

Current feature in total are 400+ feature!
> our main bot is using the premium script, if you want to buy it please contact the owner [here](https://t.me/jarsepay)

### Questions
"How many files have i encrypted for the free version script?"
> all file is now decrypted, you freely to recode this script

### Requirements

- [x] NodeJS v18 or higher
- [x] FFMPEG
- [x] Server vCPU/RAM 1/2GB

> The requirements above are the minimum requirements to running the bot. Upgrade it higher for better experience

### Screenshots
<details>
<summary><b>Initial display on Jarspy</b></summary>

| Thumbnail Menu                              |
|-----------------------------------|
| ![sticker](https://telegra.ph/file/8a49e73275688777e96b0.jpg) |

</details>
<br>

> New features will always be added

## Support Server
Got any questions or feedback? Join to our [WhatsApp Group](https://chat.whatsapp.com/LGrtCe82EpbKvxYohoRxKn)
