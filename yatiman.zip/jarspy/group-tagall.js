let jarspy = async (m, { conn, text, participants, isAdmin, isOwner }) => {
    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    m.reply(`${text ? `${text}\n` : ''}┌─「 Tag All 」\n` + users.map(v => '│◦❒ @' + v.replace(/@.+/, '')).join`\n` + '\n└────', null, {
        mentions: users
    })
}

jarspy.help = ['tagall']
jarspy.tags = ['group']
jarspy.command = ['tagall']
jarspy.admin = true
jarspy.group = true

export default jarspy
