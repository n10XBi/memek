/*
  • Fixed by Jarsépay
  • Github: https://github.com/jarsepay
  • Bot Script: https://github.com/jarsepay/Jarspy-Bot
  • My Bot: https://chat.whatsapp.com/KieFrG8MEt7C99IJKYS8qE
  • Ada kesulitan? Hubungi saya wa.me/6282148864989 (Jarsépay)
*/

import Helper from '../lib/helper.js'
import { promises as fs } from 'fs'
import { tmpdir, platform } from 'os'
import { join } from 'path'

const TIME = 1000 * 60 * 60

const __dirname = Helper.__dirname(import.meta)

export default async function clearSessions() {
	const ses = [tmpdir(), join(__dirname, '../sessions')]
	const filename = []

	await Promise.allSettled(ses.map(async (dir) => {
		const files = await fs.readdir(dir)
		for (const file of files) {
			if (file != 'creds.json') filename.push(join(dir, file))
		}
	}))

	return await Promise.allSettled(filename.map(async (file) => {
		const stat = await fs.stat(file)
		if (stat.isFile() && (Date.now() - stat.mtimeMs >= TIME)) {
			if (platform() === 'win32') {
				let fileHandle
				try {
					fileHandle = await fs.open(file, 'r+')
				} catch (e) {
					return e
				} finally {
					await fileHandle?.close()
				}
			}
			await fs.unlink(file)
		}
	}))
}
